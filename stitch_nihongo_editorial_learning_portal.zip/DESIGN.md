# Design System Strategy: The Scholarly Curator

## 1. Overview & Creative North Star

This design system is built upon the **"Scholarly Curator"** North Star. Unlike standard educational apps that feel like utility tools, this system is an editorial anthology. It treats language learning as a premium, tactile experience—akin to flipping through a high-end cultural magazine or a bespoke travel journal.

To break the "template" look common in EdTech, we employ **Intentional Asymmetry**. Elements should not always sit perfectly centered; use generous, uneven white space and overlapping components (e.g., a Japanese character floating partially outside its container) to create a sense of organic movement. The goal is a layout that feels "designed" rather than "generated."

---

## 2. Color & Surface Philosophy

Our palette balances the earthy depth of Japanese forests (`primary`: `#0f5238`) with the warmth of traditional ceramics (`secondary`: `#a33d23`).

### The "No-Line" Rule
Standard UI relies on 1px borders to separate ideas. This design system prohibits them. **Boundaries must be defined solely through background color shifts.** 
- Use `surface-container-low` to define a sidebar or a content section against the `surface` background.
- Structural separation is achieved through vertical rhythm and tonal contrast, never a line.

### Surface Hierarchy & Nesting
Treat the interface as physical layers of fine paper. 
- **Base Layer:** `surface` (#f6faff).
- **Secondary Content Area:** `surface-container-low` (#ecf5fd).
- **Interactive Cards:** `surface-container-lowest` (#ffffff).
- **Nesting:** When placing a card inside a secondary area, the card must use the "lowest" (brightest) tier to "pop" toward the user without needing a heavy shadow.

### Signature Textures & Glassmorphism
- **CTAs:** Use a subtle linear gradient for `primary` buttons, transitioning from `primary` (#0f5238) to `primary-container` (#2d6a4f) at a 135-degree angle. This adds "soul" and depth.
- **Floating Overlays:** Use Glassmorphism for mobile navigation or search overlays. Apply `surface-container-lowest` at 80% opacity with a `24px` backdrop blur. This ensures the editorial background remains visible but softened.

---

## 3. Typography

The typography is a dialogue between the classical Western serif and the clean, modern Japanese gothic.

- **Display & Headlines (Newsreader):** Used for large, evocative titles. These should be set with tight letter-spacing (-2%) to feel authoritative and "ink-on-paper."
- **Body & Labels (Inter):** High-legibility sans-serif for functional text. 
- **Character Work (Noto Sans JP):** Japanese text should be rendered slightly larger than its English counterpart (approx 110%) to account for visual density.

**Editorial Hierarchy:**
- **Display LG (3.5rem):** Reserved for chapter headings or major milestones.
- **Title MD (1.125rem):** Used for card headers, always in `on-surface` to maintain contrast.

---

## 4. Elevation & Depth

We move away from the "Material 2" shadow style toward **Tonal Layering**.

- **The Layering Principle:** Depth is "stacked." A `surface-container-highest` element feels closer to the user than a `surface-container-low` element.
- **Ambient Shadows:** When a shadow is strictly necessary for a "floating" state (e.g., a dragged kanji card), use a highly diffused shadow:
  - `box-shadow: 0 12px 32px -4px rgba(20, 29, 35, 0.06);`
  - The color is a tint of our `on-surface` (#141d23), never pure black.
- **The "Ghost Border":** For accessibility in inputs, if a boundary is required, use `outline-variant` at **15% opacity**. It should be a whisper of a line, felt rather than seen.

---

## 5. Components

### Cards
- **Construction:** Use `surface-container-lowest` with a `radius-xl` (0.75rem).
- **Prohibition:** No divider lines between card header and body. Use a `1.5rem` (24px) gap to separate content blocks.
- **Hover:** On hover, the card should lift using a subtle Y-axis shift (-4px) and a transition to a slightly higher surface tint.

### Buttons
- **Primary:** `primary` fill, `on-primary` text. `radius-full` for a sophisticated, pill-shaped look.
- **Secondary:** `secondary-container` fill with `on-secondary-container` text. This is for high-priority secondary actions like "Mark as Mastered."
- **Tertiary:** No background. Use `primary` text with a `label-md` weight.

### Level Badges
Badges should feel like small, silk-screened labels:
- **Beginner:** `primary-fixed` background / `on-primary-fixed-variant` text.
- **Intermediate:** `surface-container-highest` background / `on-surface` text.
- **Advanced:** `secondary-fixed` background / `on-secondary-fixed-variant` text.

### Input Fields
- **Background:** `surface-container-low`.
- **States:** On focus, transition the background to `surface-container-lowest` and apply a `2px` "Ghost Border" in `primary` at 20% opacity.

---

## 6. Do’s and Don’ts

### Do:
- **Use "The Bleed":** Allow decorative Japanese characters or illustrations to bleed off the edge of cards or the screen.
- **Embrace White Space:** If a section feels crowded, increase the spacing to the next tier in the scale rather than adding a divider.
- **Layer Color:** Place `tertiary-container` behind a `display-lg` heading to create a "highlight" effect that mimics a physical marker.

### Don’t:
- **No 1px Solid Lines:** Never use `#E5E0D8` as a 100% opaque stroke for boxes.
- **No Pure Black Shadows:** Shadows must always be tinted with the `on-surface` hue.
- **No Centering Everything:** Avoid a perfectly symmetrical vertical stack. Offset your "Display" type to the left and your "Body" type to a slightly narrower container to create editorial tension.
- **No Default Inter for Headers:** Never use Inter for anything larger than `title-lg`. Use the serif for the "voice" of the platform.